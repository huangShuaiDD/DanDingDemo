//
//  WangZhi.h
//  HMYD
//
//  Created by HMYD on 15/5/13.
//  Copyright (c) 2015年 HMYD. All rights reserved.
//

#ifndef HMYD_WangZhi_h
#define HMYD_WangZhi_h

//全局
#define HMYDWZ @"http://api.app.hmyd.com:80%@"
//#define HMYDWZ @"http://api.sandbox.hmyd.cn:9003%@"
//#define HMYDWZ @"http://192.168.0.105:9001%@"
//#define HMYDWZ @"http://192.168.0.113:9001%@"
//#define HMYDWZ @"http://sandbox.hmyd.cn:9001%@"

//获取当前服务器时间

#define SEVERTIME @"/app/nommal/v1/currentTimeMillis"
//获取密匙（key）
#define SECRATEKEY @"/app/nommal/v1/str"


//推荐头幻灯片
#define TJTOPSVC @"/app/ad/v1/getSlide"
//公告列表
#define GONGGAO @"/app/article/v1/list"
//推荐底项目
#define TJDOWSVC @"/app/item/v1/getHots"
//注册验证码
#define YANZHENGMA @"/app/user/v1/sendRegisterVerifyCode"


//登录
#define LOGIN @"/app/user/v1/login"
//找回密码步骤一
#define ZHAOHUIMIMA1 @"/app/user/v1/forgetPassword"
//提交新密码
#define ZHAOHUIMIMA2 @"/app/user/v1/resetPassword"
//注册
#define REGEIST @"/app/user/v1/register"
//登出
#define LOGOUT @"/app/user/v1/logout"
//签到
#define QIANDAO @"/app/score/v1/checkIn"
//项目列表
#define TouZiLieBiao @"/app/item/v1/list"
//列表详情
#define LIEBIAOXIANGQING @"/app/item/v1/detail"
//列表项目投资记录
#define TOUZIJILU @"/app/item/v1/investRecord"
//项目介绍
#define XIANGMUJIESHAO @"/app/item/v1/getDescription"


//资产
#define ZICHAN @"/app/capital/v1/detail"
//资金明细
#define ZIJINMINGXI @"/app/capital/v1/flows"
//资金明细汇总
#define ZIJINHUIZONG @"/app/capital/v1/flowSummary"
//现金券TOP
#define XIANJIANQUANTOP @"/app/coupon/v1/couponCount"
//现金券
#define XIANJIANQUAN @"/app/coupon/v1/couponList"
//投资列表TOP
#define TOUZILIEBIAOTOP @"/app/capital/v1/investmentCount"
//投资列表
#define TOUZILIEBIAO @"/app/capital/v1/investmentList"
//回款列表
#define HUIKUANLIEBIAO @"/app/capital/v1/repaymentRecord"
//项目可用现金券
#define KEYONGXIANJINQUAN @"/app/coupon/v1/getCouponByItem"
//提交投资
#define LIJITOUZI @"/app/item/v1/submit"
//小惠钱包 收支列表
#define QIANBAO @"/app/hmwallet/v1/list"


//开户前判断 if绑卡 else卡信息
#define SANGEPANDUAN @"/app/bankCard/v1/bankCard"
//开户实名
#define KAIHUShiMingMING @"/app/account/v1/authRealName"
//绑银行卡
#define BANGKA1 @"/app/bankCard/v1/binding"
//绑银行卡推进
#define BANGKA2 @"/app/bankCard/v1/bindingAdvance"
//绑银行卡页面进入
#define BANGKAOK @"/app/bankCard/v1/bankCard"


//充值页面进入
#define CHONGZHIJINRU @"/app/deposit/v1/deposit"
//充值
#define CHONGZHI1 @"/app/deposit/v1/doDeposit"
//充值推进
#define CHONGZHI2 @"/app/deposit/v1/bindingAdvance"
//充值记录
#define CHONGZHIJILU @"/app/deposit/v1/depositHistory"
//充值总金额
#define CHONGZHIZONGJINE @"/app/deposit/v1/totalAmount"


//提现进入
#define TIXIANJINRU @"/app/withdraw/v1/withdraw"
//提现总金额
#define TIXIANZONGJINE @"/app/withdraw/v1/totalAmount"
//提现记录
#define TIXIANJILU @"/app/withdraw/v1/withdrawHistory"
//提现记录计算生成
#define TIXIANJISUAN @"/app/withdraw/v1/generateWithdrawDetail"
//提现
#define TIXIAN @"/app/withdraw/v1/doWithdraw"
//账户概览
#define ZHANGHUGAILAN @"/app/capital/v1/overview"



//获取个人信息
#define USER @"/app/user/v1/getMyInfo"
//修改昵称
#define NICHENG @"/app/user/v1/changeNickname"
//修改头像
#define TOUXIANG @"/app/user/v1/changeAvatar"
//我的总积分
#define ZONGJIFEN @"/app/score/v1/getMyScore"
//消息列表
#define XIAOXILIEBIAO @"/app/message/v1/list"
//消息详情
#define XIAOXIXIANGQING @"/app/message/v1/detail"
//设置为已读
#define XIAOXIYIDU @"/app/message/v1/read"
//删除消息
#define SHANCHUXIAOXI @"/app/message/v1/delete"
//我的积分
#define JIFENLIEBIAO @"/app/score/v1/scoreRecordList"
//奖金列表
#define JIANGJINLIEBIAO @"/app/recommend/v1/bonus"
//推荐列表
#define TUIJIANLIEBIAO @"/app/recommend/v1/recommendList"
//活动列表
#define HUODONG @"/app/activity/v1/list"
//领取奖励
#define LINGQU @"/app/activity/v1/pick"


//获取安全中心短信验证码
#define ANQUANDUANXIN @"/app/safeCenter/v1/sendSafeCenterVerifyCode"
//修改登录密码
#define XIUGAOMIMA @"/app/safeCenter/v1/changePassword"
//修改交易密码
#define XIUGAIJIAOYIMIMA @"/app/safeCenter/v1/changeSecurityCode"
//设置交易码
#define JIAOYIMIMA @"/app/safeCenter/v1/setSecurityCode"
//邮箱认证 验证码
#define YOUXIANG @"/app/safeCenter/v1/sendMailVerify"
//邮箱认证-激活邮件确认
#define YOUXIANGYANZHENG @"/app/safeCenter/v1/doActivateEmailConfirmSubmit"
//邮箱认证-重新发送验证码
#define  YOUXIANGYANZHENGMA22 @"/app/safeCenter/v1/sendActivateMailVerify"
//邮箱认证-修改邮件
#define XIUGAIYOUXIANG @"/app/safeCenter/v1/doUpdateEmailConfirmSubmit"

//安全问题-保存
#define ANQUANWENTI @"/app/safeCenter/v1/doSecurityQuestionSubmit"
//安全问题-验证
#define ANQUANWENTIYZ @"/app/safeCenter/v1/validSecurityQuestion"
//安全问题-查找
#define YUANWENTI @"/app/safeCenter/v1/findSecurityQuestion"
//安全问题-找回
#define ZHAOHUIWENTI @"/app/safeCenter/v1/doFindSecurityQuestionSubmit"


//积分
//积分兑换
#define SCORECONVERT @"/app/score/v1/conver"
#define AVAILABLEAMOUNTOFHMWALLET @"/app/item/v1/availableAmountOfHmwallet"

//系统
//系统配置
#define SYSTEMCONFIG @"/app/setting/v1/roots"
//版本升级
#define SHENGJI @"/app/version/v1/getLastVersion"

//取消预约
#define CANCELORDER @"/app/item/v1/cancelOrder"
//取消预约短信验证码
#define ORDERMESSAGE @"/app/item/v1/sendCancelOrderVerifyCode"


//积分商城

//积分商城商品列表
#define GOODSLIST @"/app/jfmall/goods/v1/list"
//商品详情
#define GOODSDETAIL @"/app/jfmall/goods/v1/detail"
//商品详情：描述
#define SPMIAOSHU @"/app/jfmall/goods/v1/commodityDescription"
//商品详情：兑换记录
#define DUIHUANJILU @"/app/jfmall/goods/v1/commodityExchangeList"
//商品详情：规格描述
#define GUIGE @"/app/jfmall/goods/v1/commoditySpecifications"
//收藏
#define SHOUCANG @"/app/jfmall/collection/v1/collection"
//收藏列表
#define SHOUCANGLIEBIAO @"/app/jfmall/collection/v1/collectionList"


//地址列表
#define DIZHI @"/app/jfmall/address/v1/addressList"
//地址：修改收货地址
#define XIUGAIDIZHI @"/app/jfmall/address/v1/addressUpdate"
//地址：添加收货地址
#define TIANJIADIZHI @"/app/jfmall/address/v1/addressAdd"
//地址：删除收货地址
#define SHANCHUDIZHI @"/app/jfmall/address/v1/addressDelete"
//地址：设置默认收获地址
#define MORENDIZHI @"/app/jfmall/address/v1/addressSetDefault"

//站内信：消息列表
#define MALLMESSAGE @"/app/jfmall/message/v1/messageList"
//站内信：删除消息
#define DELMALLMESSAGE @"/app/jfmall/message/v1/messageDelete"
//站内信：消息详情
#define DETAILMALLMESSAGE @"/app/jfmall/message/v1/messageDetail"
//站内信：设置为已读
#define YIDUMALLMESSAGE @"/app/jfmall/message/v1/messageRead"


//提交订单
#define TIJIAODINGDAN @"/app/jfmall/order/v1/orderSubmit"
//订单列表
#define DINGDANLIEBIAO @"/app/jfmall/order/v1/orderList"
//订单列表：确认收获
#define QUERENSHOUHUO @"/app/jfmall/order/v1/orderHarvest"

//专属客服列表
#define QQSVLIST @"/app/qq/v1/list"
//绑定专属客服
#define BINDQQSV @"/app/qq/v1/submit"
//取消绑定专属客服
#define REBINDQQSV @"/app/qq/v1/cancel"

#endif
