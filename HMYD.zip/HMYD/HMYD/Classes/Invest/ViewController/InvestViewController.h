//
//  InvestViewController.h
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import "RootViewController.h"

@interface InvestViewController : RootViewController

@end
