//
//  CustomTabBarViewController.h
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTabBarViewController : UITabBarController

//创建tabbar上使用的内容controllers
- (void)createContentViewControllers;

//自定义我们的一个tabBar
- (void)customTabBar;

@end
