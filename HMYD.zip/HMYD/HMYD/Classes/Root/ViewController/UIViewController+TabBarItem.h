//
//  UIViewController+TabBarItem.h
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (TabBarItem)

//定义一个方法，生成viewControleller
//生成UITabBarItem ，对各个项进行赋值
//返回生成的viewController
+ (instancetype)viewContrllerTitle:(NSString*)title normalImage:(NSString*)normalImageName selectImageName:(NSString*)selectImageName;

@end
