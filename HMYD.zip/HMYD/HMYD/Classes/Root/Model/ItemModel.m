//
//  ItemModel.m
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import "ItemModel.h"

@implementation ItemModel

- (id)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

+ (instancetype)itemModelWithDic:(NSDictionary *)dic{
    return [[self alloc] initWithDic:dic];
}

+ (NSArray *)itemModelList {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"HMItems" ofType:@"plist"];
    NSArray *items = [NSArray arrayWithContentsOfFile:path];
    NSMutableArray *newList = [NSMutableArray array];
    for (NSDictionary *dic in items) {
        ItemModel *itemModel = [ItemModel itemModelWithDic:dic];
        [newList addObject:itemModel];
    }
    return newList;
    
    
}

@end
