//
//  BaseModel.h
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
