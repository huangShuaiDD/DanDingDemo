//
//  ItemModel.h
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import "BaseModel.h"

@interface ItemModel : BaseModel

@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *className;
@property (nonatomic,copy) NSString *normalImage;
@property (nonatomic,copy) NSString *selectedImage;

- (id)initWithDic:(NSDictionary *)dic;

+ (instancetype)itemModelWithDic:(NSDictionary *)dic;

+ (NSArray *)itemModelList;

@end
