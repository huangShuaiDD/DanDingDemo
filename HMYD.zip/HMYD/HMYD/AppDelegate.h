//
//  AppDelegate.h
//  HMYD
//
//  Created by HMYD on 15/12/2.
//  Copyright © 2015年 HMYD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftSlideViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic)LeftSlideViewController *LeftSlideVC;


@end

